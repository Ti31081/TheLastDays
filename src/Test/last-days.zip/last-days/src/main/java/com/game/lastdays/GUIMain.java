package com.game.lastdays;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GUIMain extends Application {

    private int quantity = 3;
    private static int grassblocksAnzahl = 0;
    private static int treeIDCounter = 1;
    private static int stoneIDCounter = 1;
    private static Player charakter = new Player("Tom");
    private static Pane pane = new Pane();
    private static Pane pane2 = new Pane();

    public void start(Stage primaryStage) {


        Image backgroundImage = new Image("file:rsc/background.png");
        ImageView background = new ImageView(backgroundImage);
        background.setFitWidth(1200);
        background.setFitHeight(600);
        pane.getChildren().add(background);

        // Abstand zwischen den Gras-Elementen

        //hallo ist ein test

        pane.getChildren().add(charakter.getImageView());


        // Funktion zur Aktualisierung der Gras-Elemente


        // HBox zuerst leeren und dann die neue Anzahl hinzufügen

        for (int i = 0; i < quantity; i++) {
            Grassblocks grassblock = new Grassblocks(grassblocksAnzahl);
            grassblocksAnzahl++;

            pane.getChildren().add(grassblock.getImageView());
        }
            /* 
            if(playerView.getX() + 60 >= grassElements.get(grassElements.size() - 1).getX() + 80) {
                quantity++;
                grassElements.add(new ImageView(grassImage));
                grassElements.get(grassElements.size() - 1).setX(grassElements.get(grassElements.size() - 2).getX() + 100);
                grassElements.get(grassElements.size() - 1).setY(400);
                pane.getChildren().add(grassElements.get(grassElements.size() - 1));
                System.out.println("hallo");
            }
            */


        Scene scene = new Scene(pane, 1200, 600);
        scene.setOnKeyPressed(event -> {
            switch (event.getCode()) {
                // ** exit on escape pressed
                case ESCAPE:
                    System.exit(0);
                    break;
                case D:
                    // ** play walking audio when the player starts moving
                    GameAudio.playWalkingAudio();
                    charakter.startMovingRight();
                    if (charakter.getImage() != "manchenMoveR.png") {
                        charakter.setImage("manchenMoveR.png");
                    }
                    break;

                case A:
                    // ** play walking audio when the player starts moving
                    GameAudio.playWalkingAudio();
                    charakter.startMovingLeft();
                    if (charakter.getImage() != "manchenMoveL.png") {
                        charakter.setImage("manchenMoveL.png");
                    }
                    break;

                case SPACE:
                    GameAudio.playJumpingAudio();
                    charakter.jumping();
                    break;

                case E:
                    charakter.setWerkzeug("axt");
                    charakter.etwasAbbauen();
                    break;

                case Q:
                    charakter.getInventory().printWoodAmount();
            }
        });

        scene.setOnKeyReleased(event -> {
            switch (event.getCode()) {
                case D:
                    // ** stop walking audio when the player stops moving
                    GameAudio.stopWalkingAudio();
                    charakter.stopMovingRight();
                    charakter.setImage("manchenR.png");
                    break;
                case A:
                    // ** stop walking audio when the player stops moving
                    GameAudio.stopWalkingAudio();
                    charakter.stopMovingLeft();
                    charakter.setImage("manchenL.png");
                    break;
                case SPACE:
                    charakter.stopJumping();
                    break;
            }
        });

        // ** show start screen
        showStartScreen();

        pane.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.setTitle("Titel Test");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public static void grassPlazieren() {
        if (charakter.getImageView().getX() + 120 >= Grassblocks.getLastX() + 70) {

            Grassblocks grass = new Grassblocks(grassblocksAnzahl);

            pane.getChildren().add(grass.getImageView());
            System.out.println("Neues Gras hinzugefügt");
            grassblocksAnzahl++;
            treePlazieren();
            steineSpawnen();

        }

    }

    private static void treePlazieren() {
        if (Math.random() < 0.2) {
            Tree tree = new Tree(treeIDCounter, Grassblocks.getLastX() - 50, Grassblocks.getLastY() - 345);
            // ** fix the tree image position to appear behind the player (add any tree at position 1 and shift the others)
            pane.getChildren().add(1, tree.getImageView());
            System.out.println("baum erstellt");
            treeIDCounter++;
        }
    }

    public static void treeFromPaneRemove(Tree tree) {
        pane.getChildren().remove(tree.getImageView());
    }

    public static void grassFromPaneRemove(Grassblocks grassblock) {
        pane.getChildren().remove(grassblock.getImageView());
    }

    public static void steineSpawnen() {
        if (Stone.getAnzahlSteine() < 5) {       //Steine sollen sich immer wieder spawnen
            if (Math.random() < 0.2) {
                Stone stone = new Stone(Grassblocks.getLastX() - 10, Grassblocks.getLastY() - 40);
                pane.getChildren().add(stone.getImageView());
                System.out.println("Neuer Stein hinzugefügt");
            }
        }
    }

    public static boolean weiterBewegen() {
        if (charakter.getImageView().getX() + 90 >= 890) {
            Grassblocks.verschiebeBlöcke();
            Tree.verschiebeTrees();
            Stone.verschiebeSteine();
            grassPlazieren();
            return true;

        } else {
            return false;
        }
    }

    // ** show start screen
    private void showStartScreen() {
        Alert startAlert = new Alert(Alert.AlertType.NONE);
        startAlert.setTitle("Start Screen");
        startAlert.setHeaderText(null); // Remove the default header

        Label welcomeLabel = new Label("The Last Days!");
        Button startButton = new Button("Start");
        // Create a custom layout for the alert
        VBox dialogContent = new VBox(welcomeLabel, startButton);
        dialogContent.setAlignment(Pos.CENTER);
        dialogContent.setPrefHeight(400);
        dialogContent.setPrefWidth(600);

        // Handle the "Start" button action
        startButton.setOnAction(_ -> {
            GameAudio.playStartAudio();
            startAlert.setResult(ButtonType.OK); // Close the alert
        });

        // on start play start sound, start the game, then play the background sound, in case of escape were clicked exit the game
        startButton.setOnKeyPressed(keyEvent -> {
            switch (keyEvent.getCode()) {
                case ENTER:
                    GameAudio.playStartAudio();
                    startAlert.setResult(ButtonType.OK); // Close the alert
                    break;
                case ESCAPE:
                    System.exit(0);
                    break;
            }
        });

        // Set the custom layout inside the alert
        startAlert.getDialogPane().setContent(dialogContent);

        // Show the alert and wait
        startAlert.showAndWait();
    }
}
