package com.game.lastdays;

public class Quests {
    
}
