package com.game.lastdays;

public class Inventory {
    private int wood;
    private int stone;
    private int iron;
    private int gold;
    private int diamond;
    private int emerald;
    private int ruby;
    private int sapphire;
    private int topaz;
    private int amethyst;
    private int copper;
    private int silver;
    private int platinum;
    private int titanium;
    private int uranium;
    private int plutonium;
    private int antimatter;
    private int darkMatter;
    private int lightMatter;
    private int matter;
    private int antimatterMatter;
    private int darkMatterMatter;
    private int lightMatterMatter;
    private int matterMatter;
    private int antimatterMatterMatter;
    private int darkMatterMatterMatter;
    private int lightMatterMatterMatter;
    private int matterMatterMatter;
    private int antimatterMatterMatterMatter;
    private int darkMatterMatterMatterMatter;
    private int lightMatterMatterMatterMatter;
    private int matterMatterMatterMatter;
    private int antimatterMatterMatterMatterMatter;
    private int darkMatterMatterMatterMatterMatter;
    private int lightMatterMatterMatterMatterMatter;
    private int matterMatterMatterMatterMatter;
    private int antimatterMatterMatterMatterMatterMatter;
    private int darkMatterMatterMatterMatterMatterMatter;
    private int lightMatterMatterMatterMatterMatterMatter;
    private int matterMatterMatterMatterMatterMatter;
    private int antimatterMatterMatterMatterMatterMatterMatter;
    private int darkMatterMatterMatterMatterMatterMatterMatter;

    public Inventory(){
        this.wood = 0;
        this.stone = 0;
        this.iron = 0;
        this.gold = 0;
        this.diamond = 0;
        this.emerald = 0;
        this.ruby = 0;
        this.sapphire = 0;
        this.topaz = 0;
        this.amethyst = 0;
        this.copper = 0;
        this.silver = 0;
        this.platinum = 0;
        this.titanium = 0;
        this.uranium = 0;
        this.plutonium = 0;
        this.antimatter = 0;
        this.darkMatter = 0;
        this.lightMatter = 0;
        this.matter = 0;
        this.antimatterMatter = 0;
        this.darkMatterMatter = 0;
        this.lightMatterMatter = 0;
        this.matterMatter = 0;
        this.antimatterMatterMatter = 0;
        this.darkMatterMatterMatter = 0;
        this.lightMatterMatterMatter = 0;
        this.matterMatterMatter = 0;
        this.antimatterMatterMatterMatter = 0;
        this.darkMatterMatterMatterMatter = 0;
        this.lightMatterMatterMatterMatter = 0;
        this.matterMatterMatterMatter = 0;
        this.antimatterMatterMatterMatterMatter = 0;
        this.darkMatterMatterMatterMatterMatter = 0;
        this.lightMatterMatterMatterMatterMatter = 0;
        this.matterMatterMatterMatterMatter = 0;
        this.antimatterMatterMatterMatterMatterMatter = 0;
        this.darkMatterMatterMatterMatterMatterMatter = 0;
        this.lightMatterMatterMatterMatterMatterMatter = 0;
        this.matterMatterMatterMatterMatterMatter = 0;
        this.antimatterMatterMatterMatterMatterMatterMatter = 0;
        this.darkMatterMatterMatterMatterMatterMatterMatter = 0;
    }

    public void addWood(int amount){
        this.wood += amount;
    }

    public void printWoodAmount() {
        System.out.println("Du hast " + this.wood + " Holz.");
    }
}
