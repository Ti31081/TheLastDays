package com.game.lastdays;

public class Map {
    public static void Erstellung(Grassblocks gras){
        if(gras.getID() == 4 || gras.getID() == 5){
            gras.getImageView().setY(500);
        }

    }
}
