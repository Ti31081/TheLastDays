package com.game.lastdays;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;

// ** Handling Game Audio
public class GameAudio {
    private static final String BACKGROUND_AUDIO = "rsc/audio/background.mp3";
    private static final String START_AUDIO = "rsc/audio/start.mp3";
    private static final String WALKING_AUDIO = "rsc/audio/walking.wav";
    private static final String JUMPING_AUDIO = "rsc/audio/jumping.mp3";

    private static MediaPlayer walkingMediaPlayer;
    private static MediaPlayer jumpingMediaPlayer;
    private static MediaPlayer mediaPlayer;

    public static MediaPlayer playAudio(String path) {
        try {
            Media media = new Media(new File(path).toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
            return mediaPlayer;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void playStartAudio() {
        MediaPlayer mediaPlayer = playAudio(START_AUDIO);
        // Play background audio after start audio ends
        if (mediaPlayer != null)
            mediaPlayer.setOnEndOfMedia(GameAudio::playBackgroundAudio);
    }

    public static void playWalkingAudio() {
        if (walkingMediaPlayer != null && walkingMediaPlayer.getStatus() == MediaPlayer.Status.PLAYING) {
            return; // Already playing, do nothing
        }
        if (walkingMediaPlayer == null) {
            Media media = new Media(new File(WALKING_AUDIO).toURI().toString());
            walkingMediaPlayer = new MediaPlayer(media);
        }

        walkingMediaPlayer.setOnEndOfMedia(() -> {
            walkingMediaPlayer.seek(javafx.util.Duration.ZERO); // Restart audio
            walkingMediaPlayer.play();
        });

        walkingMediaPlayer.play();
    }

    public static void stopWalkingAudio() {
        if (walkingMediaPlayer != null) {
            walkingMediaPlayer.stop();
            walkingMediaPlayer = null; // Reset reference
        }
    }

    public static void playJumpingAudio() {
        if (jumpingMediaPlayer == null) {
            Media media = new Media(new File(JUMPING_AUDIO).toURI().toString());
            jumpingMediaPlayer = new MediaPlayer(media);
        }

        // Restart from the beginning and play instantly
        jumpingMediaPlayer.seek(javafx.util.Duration.ZERO);
        jumpingMediaPlayer.play();
    }

    public static void playBackgroundAudio() {
        new Thread(() -> {
            try {
                Media media = new Media(new File(BACKGROUND_AUDIO).toURI().toString());
                mediaPlayer = new MediaPlayer(media);
                mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
                mediaPlayer.setAutoPlay(true);
                mediaPlayer.play();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
