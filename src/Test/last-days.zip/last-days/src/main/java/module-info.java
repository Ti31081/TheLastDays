module com.game.lastdays {
    requires javafx.controls;
    requires java.desktop;
    requires javafx.media;

    exports com.game.lastdays;
}